package ir.poshte.revayat;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;

public class MainActivity extends Activity {
    private static final String GAME_HOST = "poshte-revayat.onrender.com";
    private static final String GAME_URL = "https://" + GAME_HOST;
    private static final int MAX_AUTO_RETRIES = 8;
    private static final long RETRY_DELAY_MS = 6000L;
    private static final int COLOR_BG = Color.rgb(16, 20, 23);
    private static final int COLOR_BAR = Color.rgb(39, 47, 53);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private TextView status;
    private String targetUrl = GAME_URL;
    private boolean hadError;
    private int retries;

    private final Runnable reloadTask = new Runnable() {
        @Override
        public void run() {
            if (webView != null) {
                webView.loadUrl(targetUrl);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        buildUi();
        targetUrl = urlFromIntent(getIntent());
        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            return;
        }
        loadTarget();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri data = intent.getData();
        // Only an invite link restarts the page; tapping the app icon again does not.
        if (data != null && isGameUri(data)) {
            targetUrl = data.toString();
            loadTarget();
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(COLOR_BG);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        status.setBackgroundColor(COLOR_BAR);
        status.setOnClickListener(v -> loadTarget());

        webView = new WebView(this);
        webView.setBackgroundColor(COLOR_BG);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                hadError = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!hadError) {
                    retries = 0;
                    status.setVisibility(View.GONE);
                    webView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    handleFailure();
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 500) {
                    handleFailure();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isGameUri(uri)) {
                    return false;
                }
                openExternal(uri);
                return true;
            }
        });

        root.addView(status, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void loadTarget() {
        handler.removeCallbacks(reloadTask);
        retries = 0;
        showStatus("در حال اتصال به بازی... اگر سرور خواب بوده، تا یک دقیقه صبر کن");
        webView.loadUrl(targetUrl);
    }

    private void handleFailure() {
        hadError = true;
        webView.setVisibility(View.INVISIBLE);
        handler.removeCallbacks(reloadTask);
        if (retries < MAX_AUTO_RETRIES) {
            retries++;
            showStatus("سرور هنوز آماده نیست؛ تلاش مجدد (" + retries + " از " + MAX_AUTO_RETRIES + ")...");
            handler.postDelayed(reloadTask, RETRY_DELAY_MS);
        } else {
            showStatus("اتصال برقرار نشد. برای تلاش دوباره اینجا بزن");
        }
    }

    private void showStatus(String text) {
        status.setText(text);
        status.setVisibility(View.VISIBLE);
    }

    private String urlFromIntent(Intent intent) {
        if (intent != null) {
            Uri data = intent.getData();
            if (data != null && isGameUri(data)) {
                return data.toString();
            }
        }
        return GAME_URL;
    }

    private static boolean isGameUri(Uri uri) {
        return uri != null && "https".equals(uri.getScheme()) && GAME_HOST.equals(uri.getHost());
    }

    private void openExternal(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) {
            return;
        }
        boolean allowed = "http".equals(scheme) || "https".equals(scheme)
                || "tg".equals(scheme) || "whatsapp".equals(scheme)
                || "sms".equals(scheme) || "smsto".equals(scheme)
                || "mailto".equals(scheme) || "tel".equals(scheme);
        if (!allowed) {
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
            // no app can handle this link
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) {
            webView.saveState(outState);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(reloadTask);
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
